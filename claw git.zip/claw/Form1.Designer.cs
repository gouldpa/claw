﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.start_btn = new System.Windows.Forms.Button();
            this.zero_btn = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.up_btn = new System.Windows.Forms.Button();
            this.floor_vsb = new System.Windows.Forms.VScrollBar();
            this.prejump_btn = new System.Windows.Forms.Button();
            this.m1_lbl = new System.Windows.Forms.Label();
            this.m2_lbl = new System.Windows.Forms.Label();
            this.m3_lbl = new System.Windows.Forms.Label();
            this.m4_lbl = new System.Windows.Forms.Label();
            this.stopp_btn = new System.Windows.Forms.Button();
            this.calibrate_btn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.serialPort2 = new System.IO.Ports.SerialPort(this.components);
            this.open_btn = new System.Windows.Forms.Button();
            this.close_btn = new System.Windows.Forms.Button();
            this.sleep_btn = new System.Windows.Forms.Button();
            this.serialPort3 = new System.IO.Ports.SerialPort(this.components);
            this.serj_lbl = new System.Windows.Forms.Label();
            this.claw_lbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // serialPort1
            // 
            this.serialPort1.BaudRate = 115200;
            this.serialPort1.PortName = "COM89";
            this.serialPort1.StopBits = System.IO.Ports.StopBits.Two;
            // 
            // start_btn
            // 
            this.start_btn.Location = new System.Drawing.Point(12, 12);
            this.start_btn.Name = "start_btn";
            this.start_btn.Size = new System.Drawing.Size(75, 23);
            this.start_btn.TabIndex = 1;
            this.start_btn.Text = "start";
            this.start_btn.UseVisualStyleBackColor = true;
            this.start_btn.Click += new System.EventHandler(this.Start_btn_Click);
            // 
            // zero_btn
            // 
            this.zero_btn.Location = new System.Drawing.Point(174, 12);
            this.zero_btn.Name = "zero_btn";
            this.zero_btn.Size = new System.Drawing.Size(75, 23);
            this.zero_btn.TabIndex = 8;
            this.zero_btn.Text = "zero";
            this.zero_btn.UseVisualStyleBackColor = true;
            this.zero_btn.Click += new System.EventHandler(this.Zero_btn_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 20;
            this.timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // up_btn
            // 
            this.up_btn.Location = new System.Drawing.Point(12, 87);
            this.up_btn.Name = "up_btn";
            this.up_btn.Size = new System.Drawing.Size(75, 23);
            this.up_btn.TabIndex = 12;
            this.up_btn.Text = "up_btn";
            this.up_btn.UseVisualStyleBackColor = true;
            this.up_btn.Click += new System.EventHandler(this.Up_btn_Click);
            // 
            // floor_vsb
            // 
            this.floor_vsb.LargeChange = 1;
            this.floor_vsb.Location = new System.Drawing.Point(954, 58);
            this.floor_vsb.Maximum = 2200;
            this.floor_vsb.Name = "floor_vsb";
            this.floor_vsb.Size = new System.Drawing.Size(44, 415);
            this.floor_vsb.TabIndex = 17;
            this.floor_vsb.Value = 1000;
            // 
            // prejump_btn
            // 
            this.prejump_btn.Location = new System.Drawing.Point(109, 87);
            this.prejump_btn.Name = "prejump_btn";
            this.prejump_btn.Size = new System.Drawing.Size(75, 23);
            this.prejump_btn.TabIndex = 24;
            this.prejump_btn.Text = "down";
            this.prejump_btn.UseVisualStyleBackColor = true;
            this.prejump_btn.Click += new System.EventHandler(this.Prejump_btn_Click);
            // 
            // m1_lbl
            // 
            this.m1_lbl.AutoSize = true;
            this.m1_lbl.Location = new System.Drawing.Point(513, 15);
            this.m1_lbl.Name = "m1_lbl";
            this.m1_lbl.Size = new System.Drawing.Size(27, 17);
            this.m1_lbl.TabIndex = 25;
            this.m1_lbl.Text = "m1";
            // 
            // m2_lbl
            // 
            this.m2_lbl.AutoSize = true;
            this.m2_lbl.Location = new System.Drawing.Point(513, 47);
            this.m2_lbl.Name = "m2_lbl";
            this.m2_lbl.Size = new System.Drawing.Size(27, 17);
            this.m2_lbl.TabIndex = 26;
            this.m2_lbl.Text = "m2";
            // 
            // m3_lbl
            // 
            this.m3_lbl.AutoSize = true;
            this.m3_lbl.Location = new System.Drawing.Point(513, 76);
            this.m3_lbl.Name = "m3_lbl";
            this.m3_lbl.Size = new System.Drawing.Size(27, 17);
            this.m3_lbl.TabIndex = 27;
            this.m3_lbl.Text = "m3";
            // 
            // m4_lbl
            // 
            this.m4_lbl.AutoSize = true;
            this.m4_lbl.Location = new System.Drawing.Point(513, 109);
            this.m4_lbl.Name = "m4_lbl";
            this.m4_lbl.Size = new System.Drawing.Size(27, 17);
            this.m4_lbl.TabIndex = 28;
            this.m4_lbl.Text = "m4";
            // 
            // stopp_btn
            // 
            this.stopp_btn.Location = new System.Drawing.Point(93, 12);
            this.stopp_btn.Name = "stopp_btn";
            this.stopp_btn.Size = new System.Drawing.Size(75, 23);
            this.stopp_btn.TabIndex = 29;
            this.stopp_btn.Text = "stop";
            this.stopp_btn.UseVisualStyleBackColor = true;
            this.stopp_btn.Click += new System.EventHandler(this.Stopp_btn_Click);
            // 
            // calibrate_btn
            // 
            this.calibrate_btn.Location = new System.Drawing.Point(265, 12);
            this.calibrate_btn.Name = "calibrate_btn";
            this.calibrate_btn.Size = new System.Drawing.Size(75, 23);
            this.calibrate_btn.TabIndex = 30;
            this.calibrate_btn.Text = "calibrate";
            this.calibrate_btn.UseVisualStyleBackColor = true;
            this.calibrate_btn.Click += new System.EventHandler(this.Calibrate_btn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(90, 602);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 17);
            this.label1.TabIndex = 34;
            this.label1.Text = "m4";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(708, 602);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 17);
            this.label2.TabIndex = 33;
            this.label2.Text = "m3";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(708, 227);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 17);
            this.label3.TabIndex = 32;
            this.label3.Text = "m2";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(90, 227);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(27, 17);
            this.label4.TabIndex = 31;
            this.label4.Text = "m1";
            // 
            // serialPort2
            // 
            this.serialPort2.BaudRate = 115200;
            this.serialPort2.PortName = "COM97";
            // 
            // open_btn
            // 
            this.open_btn.Location = new System.Drawing.Point(627, 15);
            this.open_btn.Name = "open_btn";
            this.open_btn.Size = new System.Drawing.Size(75, 23);
            this.open_btn.TabIndex = 35;
            this.open_btn.Text = "open";
            this.open_btn.UseVisualStyleBackColor = true;
            this.open_btn.Click += new System.EventHandler(this.Button1_Click);
            // 
            // close_btn
            // 
            this.close_btn.Location = new System.Drawing.Point(729, 15);
            this.close_btn.Name = "close_btn";
            this.close_btn.Size = new System.Drawing.Size(75, 23);
            this.close_btn.TabIndex = 36;
            this.close_btn.Text = "close";
            this.close_btn.UseVisualStyleBackColor = true;
            this.close_btn.Click += new System.EventHandler(this.Close_btn_Click);
            // 
            // sleep_btn
            // 
            this.sleep_btn.Location = new System.Drawing.Point(838, 15);
            this.sleep_btn.Name = "sleep_btn";
            this.sleep_btn.Size = new System.Drawing.Size(75, 23);
            this.sleep_btn.TabIndex = 37;
            this.sleep_btn.Text = "sleep";
            this.sleep_btn.UseVisualStyleBackColor = true;
            this.sleep_btn.Click += new System.EventHandler(this.Sleep_btn_Click);
            // 
            // serialPort3
            // 
            this.serialPort3.BaudRate = 115200;
            this.serialPort3.PortName = "COM13";
            // 
            // serj_lbl
            // 
            this.serj_lbl.AutoSize = true;
            this.serj_lbl.Location = new System.Drawing.Point(12, 47);
            this.serj_lbl.Name = "serj_lbl";
            this.serj_lbl.Size = new System.Drawing.Size(31, 17);
            this.serj_lbl.TabIndex = 38;
            this.serj_lbl.Text = "serj";
            // 
            // claw_lbl
            // 
            this.claw_lbl.AutoSize = true;
            this.claw_lbl.Location = new System.Drawing.Point(708, 58);
            this.claw_lbl.Name = "claw_lbl";
            this.claw_lbl.Size = new System.Drawing.Size(35, 17);
            this.claw_lbl.TabIndex = 39;
            this.claw_lbl.Text = "claw";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1122, 721);
            this.Controls.Add(this.claw_lbl);
            this.Controls.Add(this.serj_lbl);
            this.Controls.Add(this.sleep_btn);
            this.Controls.Add(this.close_btn);
            this.Controls.Add(this.open_btn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.calibrate_btn);
            this.Controls.Add(this.stopp_btn);
            this.Controls.Add(this.m4_lbl);
            this.Controls.Add(this.m3_lbl);
            this.Controls.Add(this.m2_lbl);
            this.Controls.Add(this.m1_lbl);
            this.Controls.Add(this.prejump_btn);
            this.Controls.Add(this.floor_vsb);
            this.Controls.Add(this.up_btn);
            this.Controls.Add(this.zero_btn);
            this.Controls.Add(this.start_btn);
            this.Name = "Form1";
            this.Text = "Claw";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Button start_btn;
        private System.Windows.Forms.Button zero_btn;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button up_btn;
        private System.Windows.Forms.VScrollBar floor_vsb;
        private System.Windows.Forms.Button prejump_btn;
        private System.Windows.Forms.Label m1_lbl;
        private System.Windows.Forms.Label m2_lbl;
        private System.Windows.Forms.Label m3_lbl;
        private System.Windows.Forms.Label m4_lbl;
        private System.Windows.Forms.Button stopp_btn;
        private System.Windows.Forms.Button calibrate_btn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.IO.Ports.SerialPort serialPort2;
        private System.Windows.Forms.Button open_btn;
        private System.Windows.Forms.Button close_btn;
        private System.Windows.Forms.Button sleep_btn;
        private System.IO.Ports.SerialPort serialPort3;
        private System.Windows.Forms.Label serj_lbl;
        private System.Windows.Forms.Label claw_lbl;
    }
}


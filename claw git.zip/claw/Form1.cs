﻿

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WindowsFormsApp1
{

    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }
        static double MM_SCALE = 62.5;
        static double WEST_LENGTH = 2500.0;
        static double NORTH_WIDTH = 3000.0;
        static double FLOOR_HEIGHT = 2200.0;

        double west = WEST_LENGTH / 3;
        double north = NORTH_WIDTH / 3;
        double west_old;
        double north_old;
        double floor = 0.0;
        double[] xy_dist = new double[4] { 0, 0, 0, 0 };
        double[] xyz_dist = new double[4] { 0, 0, 0, 0 };
        int[] joypad = new int[6] { 0, 0, 0, 0, 0, 0};

        double rad_deg = 180.0 / 3.1415;
        double deg_rad = 3.1415 / 180.0;

        double[] x_base = new double[4] { 0, WEST_LENGTH, WEST_LENGTH, 0 };
        double[] y_base = new double[4] { 0, 0, NORTH_WIDTH, NORTH_WIDTH };

        double scale = 10.0;
        byte motor_on = 0;
        byte send_packets = 0;
        int ii;
        string bufv = "abcdefghab cdefghab cdefghabcdef ghabcdefghabcdefgha bcdefghabcde fghabcdefgh abcdefgh";

        int claw_active = 0;
        private void Form1_Load(object sender, EventArgs e)
        {
            try { serialPort1.Open(); }
            catch { }           
            timer1.Start();

            try { serialPort2.Open(); }
            catch { sleep_btn.Text = "not connected 2"; }

            try { serialPort3.Open(); }
            catch { sleep_btn.Text = "not connected 3"; }

            try
            {
                serialPort3.ReadExisting();

            }
            catch { }
        }

        private void Zero_btn_Click(object sender, EventArgs e)
        {
            if (motor_on == 1)
            {
                motor_on = 0;
                zero_btn.Text = "off";
            }
            else
            {
                motor_on = 1;
                zero_btn.Text = "on";
            }
        }
        private void Down_btn_Click(object sender, EventArgs e)
        {
      
        }
        private void Up_btn_Click(object sender, EventArgs e)
        {
            west_old = west;
            north_old = north;
            west = WEST_LENGTH/2;
            north = NORTH_WIDTH/2;
        }
        private void Hip_vsb_Scroll(object sender, ScrollEventArgs e)
        {
        //    hip_ang = hip_vsb.Value*deg_rad;
        }
        private void Start_btn_Click(object sender, EventArgs e)
        {
            send_packets = 1;
            //motor_on = 1;
        }
        private void Timer1_Tick(object sender, EventArgs e)
        {
            check_gamepad();
            if (send_packets == 0)
            {
                Cal_3D();
                Draw_Pos();
            }
            else if (send_packets == 1)
            {
                Cal_3D();
                Draw_Pos();
                Send_Serial();
            }
            else if (send_packets == 2)
            {
                motor_on = 2;
                int i;
                for (i = 0; i < 4; i++)
                {
                    xyz_dist[i] = 4600;
                }
                m1_lbl.Text = ((int)xyz_dist[0]).ToString();
                m2_lbl.Text = ((int)xyz_dist[1]).ToString();
                m3_lbl.Text = ((int)xyz_dist[2]).ToString();
                m4_lbl.Text = ((int)xyz_dist[3]).ToString();
                Send_Serial();
                send_packets = 0;
                motor_on = 0;
                zero_btn.Text = "off";
            }
        }

        private void check_gamepad()
        {
            
            try {
                if (serialPort3.BytesToRead>0)
                    bufv = serialPort3.ReadLine();
                
            }
            catch { }


            string[] words = bufv.Split(' ');
            try
            {
                int i;
                for (i=0; i<6; i++)
                    joypad[i] = Int32.Parse(words[i]);
                
            }
            catch { }
            west_old = west;
            north_old = north;
            north -= ((joypad[1]-529) / 50);
            west += ((joypad[2] - 529) / 50);
            try
            {
                floor_vsb.Value -= ((joypad[0] - 529) / 50);
            }
            catch { }

            if (joypad[3] > 1000 && joypad[5] > 1000)
                claw_active = 1;

            if (joypad[3] < 100 && joypad[5] < 100)
            {
                claw_active = 0;
                try
                {
                    serialPort2.Write("v");
                }
                catch { }
                claw_lbl.Text = "sleep";
            }

            if (joypad[5] < 800 && claw_active == 1)
            {
                try
                {
                    serialPort2.Write("x");
                }
                catch { }
                claw_lbl.Text = "open";
            }
            if (joypad[3] < 800 && claw_active == 1)
            {
                try { serialPort2.Write("c");
                }
                catch { }
                claw_lbl.Text = "close";
            }
            serj_lbl.Text = joypad[5].ToString();
/*
            foreach (string word in words)
            {
                Console.WriteLine($"{word}");
            }
            */
            //bufv. .Parse("{0} {1} {2} [{3}, {4}, {5}] {6}");
        }
        private void Send_Serial()
        {
            string bufa = "abcdefgh";
            
            int posa;
            posa = (int)(xyz_dist[0]* MM_SCALE);
            byte[] rs485a = new byte[8] { 1, motor_on, 0, 0, 0, 0, 0, 0};
            rs485a[4] = (byte)((posa) & 0x7F);
            rs485a[5] = (byte)((posa >> 7) & 0x7F);
            rs485a[6] = (byte)((posa >> 14) & 0x7F);
            rs485a[7] = (byte)((posa >> 21) & 0x7F);
            
            bufa = Encoding.ASCII.GetString(rs485a);

            try { serialPort1.Write(bufa); }
            catch { }
            System.Threading.Thread.Sleep(1);

            int posb;
            posb = (int)(xyz_dist[1]* MM_SCALE);
            byte[] rs485b = new byte[8] { 2, motor_on, 0, 0, 0, 0, 0, 0 };
            rs485b[4] = (byte)((posb) & 0x7F);
            rs485b[5] = (byte)((posb >> 7) & 0x7F);
            rs485b[6] = (byte)((posb >> 14) & 0x7F);
            rs485b[7] = (byte)((posb >> 21) & 0x7F);

            bufa = Encoding.ASCII.GetString(rs485b);

            try { serialPort1.Write(bufa); }
            catch { }
            System.Threading.Thread.Sleep(10);
            int posc;
            posc = (int)(xyz_dist[2]* MM_SCALE);
            byte[] rs485c = new byte[8] { 3, motor_on, 0, 0, 0, 0, 0, 0 };
            rs485c[4] = (byte)((posc) & 0x7F);
            rs485c[5] = (byte)((posc >> 7) & 0x7F);
            rs485c[6] = (byte)((posc >> 14) & 0x7F);
            rs485c[7] = (byte)((posc >> 21) & 0x7F);

            bufa = Encoding.ASCII.GetString(rs485c);

            try { serialPort1.Write(bufa); }
            catch { }

            System.Threading.Thread.Sleep(1);

            int posd;
            posd = (int)(xyz_dist[3]* MM_SCALE);
            byte[] rs485d = new byte[8] { 4, motor_on, 0, 0, 0, 0, 0, 0 };
            rs485d[4] = (byte)((posd) & 0x7F);
            rs485d[5] = (byte)((posd >> 7) & 0x7F);
            rs485d[6] = (byte)((posd >> 14) & 0x7F);
            rs485d[7] = (byte)((posd >> 21) & 0x7F);
            bufa = Encoding.ASCII.GetString(rs485d);


            try { serialPort1.Write(bufa); }
            catch { }


        }
   
        private void Cal_3D()
        {
            floor = FLOOR_HEIGHT - floor_vsb.Value;
            xy_dist[0] = Math.Sqrt((west * west) + (north * north));
            xy_dist[1] = Math.Sqrt(((WEST_LENGTH - west) * (WEST_LENGTH - west)) + (north * north));
            xy_dist[2] = Math.Sqrt(((WEST_LENGTH - west) * (WEST_LENGTH - west)) + ((NORTH_WIDTH - north) * (NORTH_WIDTH - north)));
            xy_dist[3] = Math.Sqrt((west * west) + ((NORTH_WIDTH - north) * (NORTH_WIDTH- north)));
            int i;
            for (i = 0; i < 4; i++)
            {
                xyz_dist[i] = Math.Sqrt(((FLOOR_HEIGHT - floor) * (FLOOR_HEIGHT - floor)) + (xy_dist[i] * xy_dist[i]));
            }

            m1_lbl.Text = ((int)xyz_dist[0]).ToString();
            m2_lbl.Text = ((int)xyz_dist[1]).ToString();
            m3_lbl.Text = ((int)xyz_dist[2]).ToString();
            m4_lbl.Text = ((int)xyz_dist[3]).ToString();

        }
        protected override void OnMouseWheel(MouseEventArgs e)
        {
             //e.Delta;
        }
        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if ((e.X > 100) && (e.Y > 200) && ((e.X - 100) < (WEST_LENGTH / scale)) && ((e.Y-200)<(NORTH_WIDTH/scale)))
            { 
                west_old = west;
                north_old = north;
                west = (e.X - 100) * scale;
                north = (e.Y - 200) * scale;
            }
            ii++;
        }
        private void Draw_Pos()
        {
            Graphics g = CreateGraphics();
            Pen p = new Pen(Color.Navy,3);
            Pen gr = new Pen(Color.Green, 1);
            Pen erase = new Pen(Color.White,5);

            int i;
            for (i = 0; i < 4; i++)
            {
                g.DrawLine(erase, (int)(100 + x_base[i] / scale), (int)(200 + y_base[i] / scale), (int)(100 + west_old / scale), (int)(200 + north_old / scale));
            }

            for (i = 0; i < 4; i++)
            {
                g.DrawLine(p, (int)(100 + x_base[i] / scale), (int)(200 + y_base[i] / scale), (int)(100 + west / scale), (int)(200 + north / scale));
            }

            
        }

        private void Sit_btn_Click(object sender, EventArgs e)
        {
           

        }

        private void Walk_btn_Click(object sender, EventArgs e)
        {
           // walking = true;
        }

        private void Pause_btn_Click(object sender, EventArgs e)
        {
           // walking = false;
        }

        private void Prejump_btn_Click(object sender, EventArgs e)
        {
        }

        private void Stopp_btn_Click(object sender, EventArgs e)
        {
            //motor_on = 0;
            send_packets = 0;
        }

        private void Calibrate_btn_Click(object sender, EventArgs e)
        {
            send_packets = 2;
        }
        
        private void Button1_Click(object sender, EventArgs e)
        {
            try { serialPort2.Write("x"); }
            catch { }
        }
        
        
        private void open_btn_Click(object sender, EventArgs e)
        {
            try { serialPort2.Write("x"); }
            catch { }
        }

        private void Sleep_btn_Click(object sender, EventArgs e)
        {
            try { serialPort2.Write("v"); }
            catch { }
        }

        private void Close_btn_Click(object sender, EventArgs e)
        {
            try { serialPort2.Write("c"); }
            catch { }
        }
    }
}
